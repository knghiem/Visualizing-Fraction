from graphics import *
from math import *
from time import *
from turtle import *
from buttonclass import *
from random import *

class DancingPoint():
    def __init__(self,pointA,pointB,r,num,den,scale,sleeptime): #num is short for numerator :P
        #All points are tuples of x and y not objects
        #Later we'll access the tuples to get x and y to draw point objects
        self.num=num
        self.den=den
        self.pointA=pointA
        self.pointB=pointB
        self.pointAs=[pointA]
        self.pointBs=[pointB]
        self.pointCs=[]
        self.minrad=-pi*1/(8*scale)
        self.r=r
        self.scale=scale
        self.sleeptime=sleeptime
        self.DPList=[]
        self.drawList=[]

    def createPoint(self):
        self.radA=self.minrad/self.den
        self.radB=self.minrad/self.num

        self.DXA,self.DYA=self.__createPoint(self.den,self.pointAs,self.radA)
        self.DXA=self.DXA*self.den*self.num
        self.DYA=self.DYA*self.den*self.num
        print("length As",len(self.pointAs))
        
        self.DXB,self.DYB=self.__createPoint(self.num,self.pointBs,self.radB)
        self.DXB=self.DXB*self.num*self.den
        self.DYB=self.DYB*self.num*self.den
        print("length Bs",len(self.pointBs))
        
        self.__createDancingPoint()
        print("length Cs",len(self.pointCs))

    def __createPoint(self,value,pointList,rad):
        DX=[]
        DY=[]
        numPoints=16*value*self.scale
        for i in range(numPoints):
            pointi=pointList[0]
            pointiX=pointi[0]
            pointiY=pointi[1]
            rad1=rad+rad*i-pi*1/2
            
            dx=(self.r+self.r*sin(rad1))-(self.r+self.r*sin(rad+rad*(i-1)-pi*1/2))
            dy=(self.r*cos(rad1))-(self.r*cos(rad+rad*(i-1)-pi*1/2))
            
            DX.append(-dx)
            DY.append(-dy)
            pointi1X=pointiX-(self.r+self.r*sin(rad1))
            pointi1Y=pointiY-(self.r*cos(rad1))
            pointList.append((pointi1X,pointi1Y))
            
        pointList.pop(0)
        return DX,DY

    def __createDancingPoint(self):
        self.pointAs=self.pointAs*self.num
        self.pointBs=self.pointBs*self.den
        numPoints=16*self.num*self.den*self.scale
        for i in range (numPoints):
            pointA=self.pointAs[i]
            pointB=self.pointBs[i]
            pointC=(pointB[0],pointA[1])
            self.pointCs.append(pointC)
        
    
    def draw(self,win):
        legA=Line(Point(150,225),Point(750,225))
        legA.draw(win)
        legB=Line(Point(600,600),Point(600,75))
        legB.draw(win)
        
        colA = "white"
        colB = "white"
        
        countA=-1
        countB=-1
        
        countAText=Text(Point(225,100),"0")
        countAText.draw(win)
        countAText.setSize(24)
        
        countBText=Text(Point(400,525),"0")
        countBText.draw(win)
        countBText.setSize(24)
        
        for i in range (len(self.pointAs)):
            pointi=self.pointAs[i]
            pointiX=pointi[0]
            pointiY=pointi[1]
            pointiDraw=Point(pointiX,pointiY)

            legA.move(self.DXA[i],self.DYA[i])
            
            line=Line(pointiDraw,Point(225,225))
            line.draw(win)
            if i % (len(self.pointAs)/self.num) == 0:
                countA+=1
                countAText.setText(countA)
                if colA == "white":
                    colA = "gray"
                else:
                    colA = "white"
            line.setFill(colA)

            pointi=self.pointBs[i]
            pointiX=pointi[0]
            pointiY=pointi[1]
            pointiDraw=Point(pointiX,pointiY)

            legB.move(self.DXB[i],self.DYB[i])
            
            line=Line(pointiDraw,Point(525,525))
            line.draw(win)
            if i % (len(self.pointBs)/self.den) == 0:
                countB+=1
                countBText.setText(countB)
                if colB == "white":
                    colB = "gray"
                else:
                    colB = "white"
            line.setFill(colB)

            pointi=self.pointCs[i]
            pointiX=pointi[0]
            pointiY=pointi[1]
            pointiDraw=Point(pointiX,pointiY)
            pointiDraw.draw(win)
            pointiDraw.setFill("purple")
            self.DPList.append(pointiDraw)

            if i>0:
                line=Line(self.DPList[i],self.DPList[i-1])
                line.draw(win)
                line.setFill("dark blue")
            else:
                line=Line(self.DPList[i],Point(600,225))
                line.draw(win)
                line.setFill("dark blue")
            sleep(self.sleeptime)

        countAText.setText(countA+1)
        countBText.setText(countB+1)
            
        line=Line(self.DPList[0],self.DPList[len(self.pointAs)-1])
        line.draw(win)
        line.setFill("dark blue")

    def savePicture(self):
        img=Image(Point(0,0),"canvas1.gif")
        for i in range(len(self.pointCs)-1):
            point1=self.pointCs[i]
            x1=round(point1[0])-375
            y1=round(point1[1])-75
            
            point2=self.pointCs[i+1]
            x2=round(point2[0])-375
            y2=round(point2[1])-75

            dist=sqrt((x1-x2)**2+(y1-y2)**2)
            for i in range (20):
                t=0.05*i
                xp=round(x1+t*(x2-x1))
                yp=round(y1+t*(y2-y1))
                img.setPixel(xp,yp,"red")             

        point1=self.pointCs[0]
        x1=round(point1[0])-375
        y1=round(point1[1])-75

        point2=self.pointCs[len(self.pointCs)-1]
        x2=round(point2[0])-375
        y2=round(point2[1])-75

        for i in range (50):
            t=0.02*i
            xp=round(x1+t*(x2-x1))
            yp=round(y1+t*(y2-y1))
            img.setPixel(xp,yp,"red") 

        
##            img.setPixel(x1,y1,"red")
                    
        img.save("fraction.gif")
            
def orbit(win,num,den):

    if num<5 and den<5:
        scale=2
        sleeptime=0.02
    elif num>5 and den>5:
        scale=1
        sleeptime=0
    else:
        scale=1
        sleeptime=0.02
    
##    winW=750
##    winH=700
##    win=GraphWin("test",winW,winH)
##    win.setBackground("white")

    start=Button(win,40,75,Point(375,70),"Start","lavenderblush")

    r=75
    xA,yA=225,225
    xB,yB=525,525
    
    circleA=Circle(Point(xA,yA),r)
    circleA.draw(win)
    
    circleB=Circle(Point(xB,yB),r)
    circleB.draw(win)
    
    pointA=Point(xA+r,yA)
    pointB=Point(xB+r,yB)

    pointC=Point(xB+r,yA)
    pointC.draw(win)
    
    lineA=Line(pointA,pointC)
    lineA.draw(win)
    lineB=Line(pointB,pointC)
    lineB.draw(win)

    line1=Line(Point(xA,yA),pointA)
    line1.draw(win)
    line2=Line(Point(xB,yB),pointB)
    line2.draw(win)
    
    numText=Text(Point(xA,425),str(num))
    numText.draw(win)
    numText.setSize(60)

    denText=Text(Point(xA,575),str(den))
    denText.draw(win)
    denText.setSize(60)

    fracText=Text(Point(xA,450),"__")
    fracText.draw(win)
    fracText.setSize(60)
    fracText.setStyle("bold")


    pt=win.getMouse()
    while not start.isClicked(pt):
        pt=win.getMouse()

    lineA.undraw()
    lineB.undraw()
    dancingPoint=DancingPoint((xA+r,yA),(xB+r,yB),r,num,den,scale,sleeptime)
    dancingPoint.createPoint()
    dancingPoint.draw(win)
    dancingPoint.savePicture()
    
