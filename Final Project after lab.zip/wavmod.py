# Sound Processing using .wav files
# Adapted from http://www.eg.bucknell.edu/~csci203/2012-fall/hw/hw03/hw3pr4.html
#
from random import *
import math
from csaudio import *
#csaudio contains functions like play(), readWav(), and writeWav()

class WavMod:
    """WavMod constructor takes:
        fileName, a string indicating the sound you wish to use.
        outputFile, an OPTIONAL string indicating the name to which
                     you wish to save the modified sound.
                     If you don't specify a second input,
                     the new sound will be saved as "out.wav"
    """
    def __init__(self,fileName, outputFile = "out.wav"):
        self.wavFile = fileName
        self.newFile = outputFile
    
    # a function to make sure everything is working

    def volume(self,fraction):
        samples, sampleRate = readWav(self.wavFile)
        length = len(samples)
        newSamples=[]
        for i in range (length):
            newSamples.append(samples[i]*fraction)
        writeWav(newSamples,sampleRate,self.newFile)
        play(self.newFile)
        return newSamples

    def pureTone(self,freq,duration):
        numSamples=int(22050*duration)
        sample=[]
        for i in range(numSamples):
            y=32767*math.cos(2*math.pi*freq*(i/numSamples))
            sample.append(y)
        writeWav(sample,numSamples,self.newFile)
        play(self.newFile)
        return sample

    def __pureTone(self,freq,duration):
        numSamples=int(22050*duration)
        sample=[]
        for i in range(numSamples):
            y=32767*math.cos(2*math.pi*freq*(i/numSamples))
            sample.append(y)
        writeWav(sample,numSamples,self.newFile)
        return sample

    def melody(self,freq,lst,lst2):
        for i in range(len(lst)):
            frac=lst[i]
            self.pureTone(freq*frac,lst2[i]*0.25)

    def melodicMajorTriads(self,freq1,duration):
        self.pureTone(freq1,duration)
        self.pureTone(freq1*1.26,duration)
        self.pureTone(freq1*1.5,duration)

    def harmonicTriads(self,freq1,duration,power):
        sample1=self.__pureTone(freq1,duration)
        sample2=self.__pureTone(freq1*1.26,duration)
        sample3=self.__pureTone(freq1*1.5,duration)

        sample1=self.__volume(sample1,power[0])
        sample2=self.__volume(sample2,power[1])
        sample3=self.__volume(sample3,power[2])
        
        sample=[]
        numSamples=int(22050*duration)

        for i in range(numSamples):
            note1=sample1[i]
            note2=sample2[i]
            note3=sample3[i]
            note=(note1+note2+note3)/3
            sample.append(note)
        writeWav(sample,numSamples,self.newFile)
        play(self.newFile)


def main():
    wavMod=WavMod("swfaith.wav")
    wavMod.melody(261,[1,3/2,2,2,3/2,1,3/2,2,9/4,2,2,3/2,1,3/2,2,9/4,9/4,2,3/2,9/4,1,3/2,3/2,4/3,3/2,4/3,3/2,2,2],[1,1,1,0.5,0.5,1,1,2,1,1,1,1,1,1,2,1,1,1,1,1,1,2,1,1,1,1,1,1,2])
main()
